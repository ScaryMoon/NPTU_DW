

//----------------------------------------------value----------------------------------------------
let AllList=[];
const TextTitle=document.querySelector(".TextTitle")
const TextBody =document.querySelector(".TextBody")
TextBody.textContent="";
let getTitle="";
let getBody;

let SmallView=document.querySelector(".SmallView");
//---------------------------------------------function---------------------------------------------

// 新增 新的list
const btn = function(){                                        
    const time1 =new Date().toISOString().slice(0,10);
        const Ttemp=new Date().toISOString().slice(11,13)
        let time2=parseInt(Ttemp)+8>23? 24-(parseInt(Ttemp)+8) : parseInt(Ttemp)+8
        time2=time2.toString()
        const time4 = new Date().toISOString().slice(13,21);
        // const time3=time1+"_"+hour+time2;
        const time3=time1+"_"+time2+time4;
        // console.log(time3)
    clearView()
    let obj={
        Title:getTitle="Title:",
        Body:getBody="detail",
        Done:false,
        Delete:false,
        Time:time3
    };        
    let inHTML=`
    <div class="Small" time="${time3}" onclick=WhichIsSelect("${time3}")>
        <div class="SmallTitle">Title:</div>
            <div class="SmallBody">detail</div>
            
                <div class="selected_icon hidden">
                 <a class="icon IconDone  green bi bi-check-circle  " onclick=done() ></a>
                    <a class="icon IconTrash red bi bi-trash3  " onclick=trash() ></a>
                
                </div> 
                 
                <div class="date-time">${time3}</div>

    </div>
    `;
    AllList.push(obj);//加入not done []
    // localStorage.setItem("AllList", JSON.stringify(AllList));
 
    SmallView.insertAdjacentHTML("beforeend",inHTML);

    
}

//我選到了這個!!!
const WhichIsSelect=function(WhichOne){      
    console.log(SmallView)           
    clearView()
    let a = document.querySelectorAll(".Small");
    a.forEach((select)=>{
        select.classList.remove("selected")
        selected_icon=select.querySelector(".selected_icon")
        selected_icon.classList.add("hidden")
        
        let b=select.getAttribute('time')
        if(b==WhichOne){

            select.classList.add("selected");
            selected_icon.classList.remove("hidden")
            // console.log("selected",select.innerHTML)
            //丟給右邊去顯示
            let getindex;
            AllList.forEach((Index)=>{
                if(Index.Time==b){getindex=AllList.indexOf(Index)}
            })
            getTitle=AllList[getindex].Title==""?"Title:":AllList[getindex].Title
            getBody=AllList[getindex].Body==undefined?"detail":AllList[getindex].Body
            TextTitle.value=getTitle;
            TextBody.value=getBody;
            
        }

    });
    
}


//更新內容
const saveIn=function(){
    console.log(SmallView)
    let WhoWant2SaveIn = document.querySelector(".selected");
    let time =WhoWant2SaveIn.getAttribute("time")
    //-------time update
        const time1 =new Date().toISOString().slice(0,10);
        const Ttemp=new Date().toISOString().slice(11,13)
        let time2=parseInt(Ttemp)+8>23? 24-(parseInt(Ttemp)+8) : parseInt(Ttemp)+8
        time2=time2.toString()
        const time4 = new Date().toISOString().slice(13,21);
        // const time3=time1+"_"+hour+time2;
        const time3=time1+"_"+time2+time4;
    //------------------
    AllList.forEach((list)=>{
        if(list.Time == time){
            list.Title = TextTitle.value
            list.Body=TextBody.value
            list.Time=time3
            WhoWant2SaveIn.removeAttribute("time")
            WhoWant2SaveIn.setAttribute("time",time3)
            WhoWant2SaveIn.removeAttribute("onclick")
            let string = `WhichIsSelect(\"${time3}\")`
            WhoWant2SaveIn.setAttribute("onclick",string)
            console.log("變更後:",WhoWant2SaveIn)
            
        }
    })
    // console.log(SmallView)
    // console.log(AllList[0].Title,AllList[0].Body,AllList[0].Done,AllList[0].Delete)
    WhoWant2SaveIn.querySelector(".SmallTitle").innerHTML=TextTitle.value.length>20?TextTitle.value.slice(0,20)+"...":TextTitle.value;
    WhoWant2SaveIn.querySelector(".SmallBody").innerHTML=TextBody.value.length>20?TextBody.value.slice(0,20)+"...":TextBody.value;
    WhoWant2SaveIn.querySelector(".date-time").innerHTML=time3
    // console.log("html:",WhoWant2SaveIn.querySelector(".date-time").innerHTML)
}

//----------------------------icon click 變圖案------------------------------

const done = function(){
    let selected = document.querySelector(".selected")
    let time=selected.getAttribute("time")

    console.log("click done time:",time)
    AllList.forEach((List)=>{
        if(List.Time==time){
            let IconDone = selected.querySelector(".IconDone")
            if(List.Done==true){
                IconDone.classList.replace("bi-check-circle-fill","bi-check-circle")
                List.Done=false;
            }else{
                IconDone.classList.replace("bi-check-circle","bi-check-circle-fill")
                List.Done=true;
            }
            
        }
    });
}

const trash = function(){
    let selected = document.querySelector(".selected")
    let time=selected.getAttribute("time")
    AllList.forEach((List)=>{
        if(List.Time==time){
            let IconTrash =selected.querySelector(".IconTrash")
            if(List.Delete==true){
                IconTrash.classList.replace("bi-trash3-fill","bi-trash3")
                List.Delete=false;
            }else{
                alert("Delete Success")
                IconTrash.classList.replace("bi-trash3","bi-trash3-fill")
                List.Delete=true;
            }
            
        }
    });
}


//--------------------------tab show------------------------------
const Process=function(){
    let button=document.querySelector(".IconAdd")
    button.classList.remove("hidden")
    clearView()
    SmallView.innerHTML=``
    // console.log(    SmallView.innerHTML    )
    AllList.forEach((ObjgetNDND)=>{
        if(ObjgetNDND.Done==false&&ObjgetNDND.Delete==false){

            let html=
            `
            <div class="Small" time="${ObjgetNDND.Time}" onclick=WhichIsSelect("${ObjgetNDND.Time}")>
                <div class="SmallTitle">${ObjgetNDND.Title==undefined?"Title":ObjgetNDND.Title.length>20?ObjgetNDND.Title.slice(0,20)+" . . . ":ObjgetNDND.Title}</div>
                <div class="SmallBody">${ObjgetNDND.Body==undefined?"detail":ObjgetNDND.Body.length>20?ObjgetNDND.Body.slice(0,20)+" . . . ":ObjgetNDND.Body}</div>
                    
                    <div class="selected_icon hidden">
                        <a class="icon IconDone  green bi ${ObjgetNDND.Done==true?"bi-check-circle-fill":"bi-check-circle"}  " onclick=done() ></a>
                        <a class="icon IconTrash red bi ${ObjgetNDND.Delete==true?"bi-trash3-fill":"bi-trash3"}  " onclick=trash() ></a>
                    </div> 
                    <div class="date-time">${ObjgetNDND.Time}</div>
            </div>
            `;
            SmallView.insertAdjacentHTML("beforeend",html)
        }

    })
}
const Complete = function(){
    let button=document.querySelector(".IconAdd")
    button.classList.add("hidden")
    clearView()
    SmallView.innerHTML=``
    // console.log(    SmallView.innerHTML    )
    AllList.forEach((ObjgetYDND)=>{
        if(ObjgetYDND.Done==true&&ObjgetYDND.Delete==false){

            let html=
            `
            <div class="Small" time="${ObjgetYDND.Time}" onclick=WhichIsSelect("${ObjgetYDND.Time}")>
                <div class="SmallTitle">${ObjgetYDND.Title==undefined?"Title":ObjgetYDND.Title.length>20?ObjgetYDND.Title.slice(0,20)+" . . . ":ObjgetYDND.Title}</div>
                <div class="SmallBody">${ObjgetYDND.Body==undefined?"detail":ObjgetYDND.Body.length>20?ObjgetYDND.Body.slice(0,20)+" . . . ":ObjgetYDND.Body}</div>
                    
                    <div class="selected_icon hidden">
                        <a class="icon IconDone  green bi ${ObjgetYDND.Done==true?"bi-check-circle-fill":"bi-check-circle"}  " onclick=done() ></a>
                        <a class="icon IconTrash red bi ${ObjgetYDND.Delete==true?"bi-trash3-fill":"bi-trash3"}  " onclick=trash() ></a>
                    </div> 
                    <div class="date-time">${ObjgetYDND.Time}</div>
            </div>
            `;
            SmallView.insertAdjacentHTML("beforeend",html)
        }

    })
}
const Deleted = function(){
    let button=document.querySelector(".IconAdd")
    button.classList.add("hidden")
    clearView()
    SmallView.innerHTML=``
    // console.log(    SmallView.innerHTML    )
    AllList.forEach((ObjgetYDYD)=>{
        if(ObjgetYDYD.Delete==true){

            let html=
            `
            <div class="Small" time="${ObjgetYDYD.Time}" onclick=WhichIsSelect("${ObjgetYDYD.Time}")>
                <div class="SmallTitle">${ObjgetYDYD.Title==undefined?"Title":ObjgetYDYD.Title.length>20?ObjgetYDYD.Title.slice(0,20)+" . . . ":ObjgetYDYD.Title}</div>
                <div class="SmallBody">${ObjgetYDYD.Body==undefined?"detail":ObjgetYDYD.Body.length>20?ObjgetYDYD.Body.slice(0,20)+" . . . ":ObjgetYDYD.Body}</div>
                    
                    <div class="selected_icon hidden">
                        <a class="icon IconDone  green bi ${ObjgetYDYD.Done==true?"bi-check-circle-fill":"bi-check-circle"}  " onclick=done() ></a>
                        <a class="icon IconTrash red bi ${ObjgetYDYD.Delete==true?"bi-trash3-fill":"bi-trash3"}  " onclick=trash() ></a>
                    </div> 
                    <div class="date-time">${ObjgetYDYD.Time}</div>
            </div>
            `;
            SmallView.insertAdjacentHTML("beforeend",html)
        }

    })
}

const clearView=function(){
    TextBody.value=""
    TextTitle.value=""
}





//------------------------------------------------------------------------------------------